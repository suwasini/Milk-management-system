document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const role = document.getElementById('role').value;
    
    if (role === 'farmer') {
      window.location.href = 'farmer-dashboard.html';
    } else if (role === 'collector') {
      window.location.href = 'collector-dashboard.html';
    } else if (role === 'buyer') {
      window.location.href = 'buyer-dashboard.html';
    } else {
      alert('Please select a role');
    }
  });
  